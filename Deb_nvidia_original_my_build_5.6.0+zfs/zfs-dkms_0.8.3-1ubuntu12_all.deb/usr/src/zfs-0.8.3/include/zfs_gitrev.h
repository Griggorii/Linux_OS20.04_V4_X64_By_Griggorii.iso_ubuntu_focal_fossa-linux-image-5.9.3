#define	ZFS_META_GITREV "unknown"
