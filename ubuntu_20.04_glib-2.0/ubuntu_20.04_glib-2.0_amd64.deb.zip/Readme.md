                                                                  Ubuntu 20.04 griggorii new build 2022

folder install command

lsof /usr/lib/x86_64-linux-gnu/libglib-2.0.so.0.6400.6 & sudo dpkg -i *.deb && sudo update-initramfs -u -v && clear && exit

Problem dependency ? Fix

sudo apt update && sudo apt install -f
