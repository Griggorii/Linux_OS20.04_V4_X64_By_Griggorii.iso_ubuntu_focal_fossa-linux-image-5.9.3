#!/bin/sh

plymouth --hide-splash 2>/dev/null || :
