#!/bin/sh

CDROOT=0
. /lib/gensplash-lib.sh
splash verbose
