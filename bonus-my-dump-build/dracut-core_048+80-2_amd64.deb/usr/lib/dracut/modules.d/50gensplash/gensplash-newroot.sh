#!/bin/sh

CDROOT=0
. /lib/gensplash-lib.sh
splash set_msg 'Switching to new root'
