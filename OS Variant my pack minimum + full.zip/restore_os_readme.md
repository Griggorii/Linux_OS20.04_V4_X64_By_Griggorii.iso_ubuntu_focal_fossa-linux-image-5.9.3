                                    Griggorii@gmail.com stable os ubuntu 20.04 glib-2.31

Not wine i386 light fast special_os_wayland_pack.txt

$ sudo apt update &&  sudo apt-get dselect-upgrade && sudo dpkg --set-selections < special_os_wayland_pack.txt

and variant not fast big initramfs special_os_wayland_pack+i386_wine.txt

sudo apt update &&  sudo apt-get dselect-upgrade && sudo dpkg --set-selections< special_os_wayland_pack+i386_wine.txt
